<?php
declare(strict_types=1);

/**
 * Russian shared-hosting adapter for Xeni_brows booking requests.
 * Configure credentials in booking-secrets.php OUTSIDE public_html.
 * Never commit secrets or include them in the deployed public_html directory.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function answer(int $code, string $message): never {
    http_response_code($code);
    echo json_encode(['ok' => $code === 200, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') answer(405, 'Метод не поддерживается.');
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    // Do not accept personally identifiable information over HTTP.
    answer(403, 'Для отправки заявки необходимо защищённое соединение HTTPS.');
}
if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') === false) answer(415, 'Неподдерживаемый формат.');
if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 6000) answer(413, 'Слишком длинная заявка.');
$raw = file_get_contents('php://input', false, null, 0, 6001);
if ($raw === false || strlen($raw) > 6000) answer(413, 'Слишком длинная заявка.');
$data = json_decode($raw, true);
if (!is_array($data)) answer(400, 'Некорректные данные заявки.');
if (!empty($data['website'])) answer(200, 'Заявка принята.');
if (($data['consent'] ?? false) !== true) answer(400, 'Необходимо согласие на обработку персональных данных.');
function txt(array $data, string $key, int $max): string {
    $v = $data[$key] ?? '';
    return is_string($v) ? mb_substr(trim($v), 0, $max) : '';
}
$name = txt($data, 'name', 120);
$phone = txt($data, 'phone', 32);
$service = txt($data, 'service', 80) ?: 'Пока не определилась';
$method = txt($data, 'method', 12);
$profile = txt($data, 'profile', 200);
$details = txt($data, 'details', 1000);
$services = ['Пока не определилась','Оформление бровей','Ламинирование ресниц','Комплекс «брови + ресницы»','Перманентный макияж'];
$methods = ['telegram'=>'Telegram','vk'=>'ВКонтакте','phone'=>'По телефону'];
$digits = preg_replace('/\D/', '', $phone);
if (mb_strlen($name) < 3 || mb_strlen($name) > 120 || strlen($digits) < 10 || strlen($digits) > 15
    || !in_array($service, $services, true) || !isset($methods[$method])) {
    answer(400, 'Проверьте имя, телефон и выбранную услугу.');
}
$privateFile = dirname(__DIR__, 2) . '/booking-secrets.php';
if (!is_file($privateFile)) {
    answer(503, 'Отправка заявок пока не подключена. Пожалуйста, свяжитесь со студией напрямую.');
}
$private = require $privateFile;
$token = is_array($private) ? ($private['bot_token'] ?? '') : '';
$chat = is_array($private) ? ($private['chat_id'] ?? '') : '';
if (!is_string($token) || !preg_match('/^[0-9]+:[A-Za-z0-9_-]+$/', $token)
    || !is_string($chat) && !is_int($chat) || (string)$chat === '') {
    answer(503, 'Отправка заявок пока не подключена. Пожалуйста, свяжитесь со студией напрямую.');
}
$clean = static fn(string $v): string => str_replace(['<','>'], '', $v);
$lines = [
    '🌿 Новая заявка Xeni_brows',
    '',
    'Имя: ' . $clean($name),
    'Услуга: ' . $service,
    'Телефон: ' . $clean($phone),
    'Способ связи: ' . $methods[$method],
];
if ($method !== 'phone' && $profile !== '') $lines[] = 'Контакт: ' . $clean($profile);
if ($details !== '') $lines[] = 'Дата, время или вопрос:' . "\n" . $clean($details);
$ch = curl_init('https://api.telegram.org/bot' . $token . '/sendMessage');
if ($ch === false) answer(502, 'Не удалось отправить заявку. Попробуйте ещё раз.');
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['chat_id'=>(string)$chat,'text'=>implode("\n", $lines)], JSON_UNESCAPED_UNICODE),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 4,
    CURLOPT_TIMEOUT => 10,
]);
$result = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$decoded = is_string($result) ? json_decode($result, true) : null;
if ($status !== 200 || !is_array($decoded) || ($decoded['ok'] ?? false) !== true) {
    error_log('Xeni_brows booking delivery failed; HTTP status: ' . (int)$status);
    answer(502, 'Не удалось отправить заявку. Попробуйте ещё раз или напишите мне напрямую.');
}
answer(200, 'Спасибо! Ваша заявка отправлена. Я свяжусь с вами для уточнения времени.');
